class Student:
    def __init__(self, name: str, age: int, grades: list[int]):
        self.name = name
        self.age = age
        self.grades = grades

    def average(self) -> float:
        return sum(self.grades) / len(self.grades) if self.grades else 0.0

    def __str__(self) -> str:
        return f"Студент {self.name}, возраст {self.age}, средняя оценка: {self.average():.2f}"

    def __repr__(self) -> str:
        return f"Student(name='{self.name}', age={self.age}, grades={self.grades})"

import unittest
from student import Student

class TestStudent(unittest.TestCase):
    def test_str_output(self):
        s = Student("Анна", 21, [4, 5, 5])
        self.assertEqual(str(s), "Студент Анна, возраст 21, средняя оценка: 4.67")

    def test_repr_output(self):
        s = Student("Анна", 21, [4, 5, 5])
        self.assertEqual(repr(s), "Student(name='Анна', age=21, grades=[4, 5, 5])")

    def test_average(self):
        s = Student("Петр", 22, [3, 4, 5])
        self.assertAlmostEqual(s.average(), 4.0)

if __name__ == '__main__':
    unittest.main()

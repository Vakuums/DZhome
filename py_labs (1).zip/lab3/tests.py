import unittest
from factorial import LazyFactorial

class TestLazyFactorial(unittest.TestCase):
    def test_factorial_value(self):
        f = LazyFactorial(4)
        val1 = f.expensive_computation
        val2 = f.expensive_computation
        self.assertIs(val1, val2)

    def test_factorial_zero(self):
        f = LazyFactorial(0)
        self.assertEqual(f.expensive_computation, 1)
        
    def test_factorial_(self):
        f = LazyFactorial(5)
        self.assertEqual(f.expensive_computation, 120)

if __name__ == '__main__':
    unittest.main()

class LazyProperty:
    def __init__(self, func):
        self.func = func
        self.name = func.__name__
        
    def __get__(self, instance, owner):
        if instance is None:
            return self
        value = self.func(instance)
        setattr(instance, self.name, value)  
        return value
    
class LazyFactorial:
    def __init__(self, n):
        self._n = n
        self._value = None

    @LazyProperty
    def expensive_computation(self):
        print("Computing...")
        result = 1
        for i in range(2, self._n + 1):
            result *= i
        return result
    
# Использование
if __name__ == "__main__":
    f = LazyFactorial(0)
    print(f.expensive_computation)  
    print(f.expensive_computation) 
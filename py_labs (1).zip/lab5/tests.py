import unittest
from Product import Product


class TestProduct(unittest.TestCase):

    def test_valid_product(self):
        p = Product(10.5, 3)
        self.assertEqual(p.total_cost(), 31.5)

    def test_invalid_price(self):
        with self.assertRaises(ValueError):
            Product(-1, 5)

    def test_invalid_quantity(self):
        with self.assertRaises(ValueError):
            Product(5, 0)

    def test_attribute_deletion(self):
        p = Product(5, 1)
        with self.assertRaises(AttributeError):
            del p.price


if __name__ == '__main__':
    unittest.main()

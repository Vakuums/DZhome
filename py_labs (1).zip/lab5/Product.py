class PositiveDescriptor:
    def __init__(self, name):
        self.name = name

    def __get__(self, instance, owner):
        if instance is None:
            return self
        return instance.__dict__[self.name]

    def __set__(self, instance, value):
        if value <= 0:
            raise ValueError(f"{self.name} должно быть положительным числом.")
        instance.__dict__[self.name] = value

    def __delete__(self, instance):
        raise AttributeError("Удаление атрибута запрещено")


class Product:
    price = PositiveDescriptor("price")
    quantity = PositiveDescriptor("quantity")

    def __init__(self, price: float, quantity: int):
        self.price = price
        self.quantity = quantity

    def total_cost(self) -> float:
        return self.price * self.quantity

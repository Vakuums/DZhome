import unittest
from AutoRegisterMeta import AutoRegisterMeta, Base

class TestMeta(unittest.TestCase):

    def test_registry_contains_classes(self):
        self.assertIn("Alpha", AutoRegisterMeta.registry)
        self.assertIn("Beta", AutoRegisterMeta.registry)

    def test_registry_classes_are_correct(self):
        self.assertTrue(issubclass(AutoRegisterMeta.registry["Alpha"], Base))
        self.assertTrue(issubclass(AutoRegisterMeta.registry["Beta"], Base))

    def test_action(self):
        self.assertEqual(AutoRegisterMeta.registry["Alpha"]().action(), "Alpha action")
        self.assertEqual(AutoRegisterMeta.registry["Beta"]().action(), "Beta action")


if __name__ == '__main__':
    unittest.main()

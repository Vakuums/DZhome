class AutoRegisterMeta(type):
    registry = {}

    def __new__(cls, name, bases, dct):
        new_cls = super().__new__(cls, name, bases, dct)
        if name != "Base":
            AutoRegisterMeta.registry[name] = new_cls
        return new_cls

class Base(metaclass=AutoRegisterMeta):
    pass

class Alpha(Base):
    def action(self):
        return "Alpha action"

class Beta(Base):
    def action(self):
        return "Beta action"

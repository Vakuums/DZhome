import unittest
from Range import Range

class TestRangeLike(unittest.TestCase):

    def test_range_like_forward(self):
        r = Range(3)
        self.assertEqual(list(r), [0, 1, 2])

    def test_range_like_start_stop(self):
        r = Range(2, 5)
        self.assertEqual(list(r), [2, 3, 4])

    def test_range_like_step(self):
        r = Range(1, 10, 3)
        self.assertEqual(list(r), [1, 4, 7])

    def test_range_like_negative_step(self):
        r = Range(5, 0, -2)
        self.assertEqual(list(r), [5, 3, 1])

if __name__ == '__main__':
    unittest.main()

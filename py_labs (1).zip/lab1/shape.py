from abc import ABC, abstractmethod
import math

# Абстрактный класс - фигура
class Shape(ABC):
    # Метод вычисления площади фигуры
    @abstractmethod
    def area(self) -> float:
        pass
    
    # Метод вычисления периметра фигуры
    @abstractmethod
    def perimeter(self) -> float:
        pass

# Класс - круг
class Circle(Shape):
    def __init__(self, radius: float):
        self.radius = radius

    def area(self) -> float:
        return math.pi * self.radius ** 2

    def perimeter(self) -> float:
        return 2 * math.pi * self.radius

# Класс - прямоугольник
class Rectangle(Shape):
    def __init__(self, width: float, height: float):
        self.width = width
        self.height = height

    def area(self) -> float:
        return self.width * self.height

    def perimeter(self) -> float:
        return 2 * (self.width + self.height)

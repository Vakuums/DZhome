import unittest
from shape import Circle, Rectangle
import math

class TestShapes(unittest.TestCase):

    def test_circle_area(self):
        c = Circle(1)
        self.assertAlmostEqual(c.area(), math.pi)

    def test_circle_perimeter(self):
        c = Circle(2)
        self.assertAlmostEqual(c.perimeter(), 2 * math.pi * 2)

    def test_rectangle_area(self):
        r = Rectangle(3, 4)
        self.assertEqual(r.area(), 12)

    def test_rectangle_perimeter(self):
        r = Rectangle(5, 6)
        self.assertEqual(r.perimeter(), 2 * (5 + 6))


if __name__ == '__main__':
    unittest.main()

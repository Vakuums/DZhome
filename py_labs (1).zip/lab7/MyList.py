class MyList:
    def __init__(self, *args):
        self._data = list(args)

    def __getitem__(self, index):
        return self._data[index]

    def __setitem__(self, index, value):
        self._data[index] = value

    def __delitem__(self, index):
        del self._data[index]

    def __len__(self):
        return len(self._data)

    def __iter__(self):
        return iter(self._data)

    def append(self, value):
        self._data.append(value)

    def __repr__(self):
        return f"MyList({self._data})"

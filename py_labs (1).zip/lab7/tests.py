import unittest
from MyList import MyList

class TestMyList(unittest.TestCase):

    def test_get_item(self):
        lst = MyList(1, 2, 3)
        self.assertEqual(lst[0], 1)

    def test_set_item(self):
        lst = MyList(1, 2, 3)
        lst[1] = 42
        self.assertEqual(lst[1], 42)

    def test_del_item(self):
        lst = MyList(1, 2, 3)
        del lst[1]
        self.assertEqual(len(lst), 2)
        self.assertEqual(lst[1], 3)

    def test_len(self):
        lst = MyList(10, 20)
        self.assertEqual(len(lst), 2)

    def test_iter(self):
        lst = MyList(4, 5, 6)
        self.assertEqual([x for x in lst], [4, 5, 6])

    def test_append(self):
        lst = MyList()
        lst.append(100)
        self.assertEqual(lst[0], 100)

if __name__ == '__main__':
    unittest.main()